DECK for the T1-v1 FULL-ASSEMBLY test. DO NOT PRINT until Keeper authorises it. Mark T1-v1 on the underside.
