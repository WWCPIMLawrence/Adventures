PAWLS (ring detent springs), current files, confirmed 1.4 mm PETG springs.
Per instrument: 2 x pawl_outer.stl + 2 x pawl_inner.stl  (4 pawls). Print in PETG.
Unchanged since 17 Nov; checked against the current CAD (same size and volume).
Printing for four instruments = 8 outer + 8 inner (plus spares). Print only what you do not already have.
