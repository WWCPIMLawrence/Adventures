PRINT THESE: current files only (20 Nov 2026). Everything else in the old "ALL_LATEST" folder is an older revision or a test file: ignore it.
Numbers 01 to 13 are the Chronometer. 14 is the M-72 test plate. 15 is the Dock spindle (later). Files that are not named below are not needed.

01 COVER           cover_T1-v1_KNURLED.stl  brass PLA. KNURLED rim (the owner's decision, 20 Nov; the tested covers had a smooth rim). Print ONE first and re-test press-and-turn (10 cycles) before printing more. Then draw the M3 nut in from underneath.
02 DECK            deck_T1-v1.stl           brass PLA, alone on the bed. You already have enough for now.
03 STRIPS (PETG)   strips_T1-v1_soft07      six strips per file. Two per instrument; you have a box of them.
04 PAWL OUTER      PETG, 2 per instrument   05 PAWL INNER   PETG, 2 per instrument
06 INDEX CAP       brass + ivory arrow      you need 1 more
07 OUTER RING      black + ivory numerals   you have 4
08 INNER RING      black + ivory symbols    you need 1 more. PRINT IT ALONE on the bed.
09 KNOB            brass PLA                you have 4 (one has a loose recess: reprint 1 if not done)
10 + 11 BACK PLATE  TWO FILES, import both as ONE object: 10 (black floor disc) and 11 (brass). Back face down, outer brim only. You need 1 more.
12 + 13 FRAGMENT TILES  one plate = one set of four tiles; digits (13) in black. You have 4 sets: nothing to print.
14 M-72 PLATE V2    ONE plate only (Keeper-approved 20 Nov): brass PLA, prints TOP FACE DOWN as loaded: do NOT rotate or flip. Test sheet: M72_V2_TEST_SHEET_2026-11-20.txt.  14b is the V1 plate you already printed and tested (fallback): do not reprint.
15 DOCK SPINDLE D1  not a Chronometer part; after the Chronometer tests.
NOT NEEDED: PETG retaining ring (dropped), fit-ladder rings, keyed lid, spring crown, the old latch decks and covers, the O2-v1 kit.
