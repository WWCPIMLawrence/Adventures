GATE TEST v2 - strips that stay in the seat

What changed: the strips' feet are now 1.6 mm deep (were 1.0) and fit their slots with 0.07 mm clearance per side (were 0.15).
That makes a light press fit, so the strips stay put when the cover is off and the seat is bumped.

REPRINT (all three): test_seat_gate.stl (PLA, as before), gate_bows_soft.stl and gate_bows_firm.stl (PETG, lying on their side).
The old strips will NOT fit the new seat well (their feet are shorter), and the new strips will be too tight to ever fall out of
the old seat, so replace both. Keep the soft and firm sets apart, or print them in different colours, so you can tell them apart.
Everything else (covers, plain ring) is unchanged. Do not reprint those.

FIT: a strip should push in with firm finger pressure and need a fingernail or tweezers to lift out. If it is too tight to seat,
sand the sides of the feet lightly, or tell me and I will open the clearance to 0.10 mm. If it is still loose, tell me and I will
add a small barb. A drop of CA glue on one foot is an acceptable last resort for the hunt units.
