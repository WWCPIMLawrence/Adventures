M-72 plate V2c source (21 Nov 2026). Open concepts/m72_attachment/m72_sight_plate_V2c.scad (keep the folder layout).
V2c includes V2 (V2b fallback) which includes V1. Parts: m72v2c_black_print, m72v2c_brass_print (top face down). V2b stays in m72_sight_plate_V2.scad.
