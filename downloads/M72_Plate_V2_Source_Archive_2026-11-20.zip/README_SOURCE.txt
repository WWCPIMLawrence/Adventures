M-72 Surveyor's Plate V2: source archive (20 Nov 2026)
concepts/m72_attachment/m72_sight_plate_V2.scad   the V2 source (engraved titles, rings, rules, rim notches)
concepts/m72_attachment/m72_sight_plate_concept.scad   the V1 source (kept as the rollback; V2 includes it and only removes material)
cad/chronometer.scad   the Chronometer source both files include (do not edit)
Regenerate the print file (top face down), from the folder concepts/m72_attachment:
  openscad -o m72_PLATE_V2_decorated.stl -D 'part="m72v2_plate_print"' m72_sight_plate_V2.scad
Regenerate V1:  openscad -o m72_V1.stl -D 'part="m72_plate_print"' m72_sight_plate_concept.scad
V2 checks (EMPTY unless noted): chk_v2_adds_nothing, chk_v2_rings, chk_v2_cap, chk_v2_cover, chk_v2_heads; chk_v2_stops is SOLID (the heads hold the plate up).
Font: Liberation Serif Bold (the glyph widths in the SCAD are from that font). Parameters: dec_depth 0.4, groove_w 0.5, txt_size 4.6.
