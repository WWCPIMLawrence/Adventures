# M-72 Surveyor's Observation Plate: CAD status, test plate and what is missing (20 Nov 2026)
Reply to Keeper's reminder. CAD results are predictions; **no plate has been printed or tested**. Non-production until physically accepted. No change to any Chronometer part.

## What it is and where it stands
A separate rigid printed plate that lies over the Chronometer face and shows three **pairs of windows** (an outer-ring numeral window and an inner-ring symbol window at each clock position), so the player reads the numeral and symbol pairs and compares them with the M-72 evidence. It rests on the three index-cap screw heads (no attachment) and stays inside the outer ring's edge. It is distinct from the integrated Music House aperture. **It is on the production checklist now (row 21): 4 needed, 0 printed, one test plate first.**

## Updates made for the accepted configuration (vs the 18 Nov concept)
- **Pan-head cap screws** (Keeper's screw decision) instead of socket heads: heads assumed **6.0 mm diameter x 2.4 mm high (NOT measured)**; cups are 7.0 mm across and only 0.6 mm deep, so the plate underside stays at the same height whatever the real head height is.
- **Window chamfers made one-sided.** The old symmetric chamfer ran into the plate's edge and left a 0 to 0.1 mm sliver; now the symbol window keeps a straight inner wall (1.0 mm web at the plate's inner edge) and the numeral window a straight outer wall (1.1 mm web at the outer edge). The chamfered sides still cut parallax.
- Default window layout for the test plate: **p4 / p8 / p10** (Keeper had noted it hides DIAMOND at the correct calibration). **p4 / p6 / p8** is also exported. **Keeper or Scribe must still choose the final layout**; I have no engineering preference.

## CAD checks (predictions), both layouts, head heights 2.2, 2.4 and 3.0 mm
- **Clear of** the outer and inner rings (with their raised lettering), the index cap, the pan-head screw heads (they only touch the cup roofs), and the **gate-raised T1-v1 centre cover**: all EMPTY, so no interference is predicted. Sinking the plate 0.1 mm makes the heads hit the cup roofs (SOLID, as intended: the three heads hold the plate up) while it stays clear of rings and cap.
- **Not checked:** clearance to the real printed heads; flatness of a 2.0 mm PLA annulus (the plate may flex in the hand); parallax and readability on a real print.

## Test plate for physical acceptance
`m72_TEST_PLATE_pan_heads_p4810_NONPRODUCTION.stl` (and `..._p468_...` as the alternative): 124 x 124 x 2.0 mm, **17.1 cm3**, print **flat on the bed, underside down**, no supports (the cups are shallow recesses that bridge). Rough guess: about 1 h (not measured). Colour is a decision (see below). **Do not print before the Chronometer durability tests have room; print only this one plate, not the other three.**
Owner's physical test: (1) it rests on the three cap-screw heads, level, without touching the rings or index cap; (2) rings turn freely with it on; (3) the centre cover can be removed and refitted with it on or off (note which); (4) read the pairs at the correct calibration, **outer ring XII and inner ring STAR at the fixed arrow**: windows must show the expected numeral and symbol (p4/p8/p10: IV/TREE, VIII/SUN, X/KEY); (5) viewing from above and at an angle, are the glyphs readable and unobstructed; (6) does it rock or slide off when tilted; (7) after it comes off, nothing is marked or loose.

## What I need from Scribe (and Keeper)
1. **The final window layout** (p4/p8/p10 or p4/p6/p8) or another set: Scribe has not frozen anything until Cog and the owner report a physical reading.
2. **The M-72 evidence puzzle artwork:** which numeral-symbol pairs the windows must identify, any pair-to-answer mapping, and where the evidence is to be read (photographs, card, table). I have only the geometry, not the artwork.
3. **Window labels:** does the plate carry engraved or printed marks (for example A, B, C, a title or tick marks), and in what typeface? I have drawn none.
4. **Finish and colour** (for example matte black, bone or brass) and whether lettering or raised marks on the plate are wanted.
5. **Wording and size of any instruction** that goes with the plate.
6. **Any story constraint** on which symbols may be visible (for example avoiding DIAMOND at calibration).
## What I need from the owner
Measure one **pan-head cap screw**: head diameter and height (calipers). The plate design assumes 6.0 x 2.4 mm.

## Status of the other three plates
Not started. They wait for the physical acceptance of the test plate and for the Scribe items above.
