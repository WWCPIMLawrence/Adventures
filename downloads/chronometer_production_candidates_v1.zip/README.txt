CHRONOMETER - PRODUCTION CANDIDATE FILES (17 Nov 2026)    Pre-freeze: files may change at the Thursday 19 Nov freeze.
Read PRODUCTION_PLAN_2026-11-17.md for the schedule. Quantities are for FOUR instruments, plus spares.

A_back_plates_PRINT_NOW   back_plate.stl (single colour) or the two-colour pair: back_plate_black.stl + back_plate_brass.stl imported as ONE object.
                          x4 (+1 spare). Back face down, outer brim only. Bone arrow coloured by hand. Already tested by you.
B_bases                   base.stl x4 (no lip). Brass. One per plate.
C_..._AFTER_KNOB_TEST     Do not print until the knob test decides.
   gate_G                 deck_gate.stl, cover_gate_smooth_rim.stl (PLA brass, x4 each) and uv_ring_plain_PETG.stl (PETG, x4).
   fallback_L_three_arm   deck.stl, cover.stl, uv_ring.stl (the current three-arm latch defaults), if the gate fails the knob test.
D_outer_ring              outer_ring.stl x4. Black, ivory numerals (one colour change at layer 29).
E_inner_ring              inner_ring.stl x4 (three fit on a plate). Black, ivory symbols and ribs (one change at layer 29).
F_index_cap               index_cap.stl x4. Brass, ivory arrow (change at layer 13). Cover files are in C.
G_fragment_tiles          plate_fragments.stl + plate_fragments_digits.stl: one plate = one set of four tiles (x4 sets). As tested.
H_PETG_pawls_and_strips   pawl_outer.stl x8, pawl_inner.stl x8 (PETG, 1.4 mm); gate_bows_soft.stl and gate_bows_firm.stl (six strips per file,
                          PETG, on their side, press-fit feet v2): print 6 soft files for the soft set and keep soft and firm sets apart. Gate variant only.
I_keystone_AFTER_...      keystone.stl x4. Hold until the Phillips screw measurements are in (or I confirm the socket-head pocket).
