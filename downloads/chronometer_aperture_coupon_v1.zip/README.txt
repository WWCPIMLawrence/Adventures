CHRONOMETER - ASYMMETRIC APERTURE COUPON  (asym_v1)      PROPOSAL / COUPON ONLY - nothing here is production-approved

PRINT NOW: only the coupon (about 15 minutes on the P1S). The folder 3_LATER holds a whole plate and base for after the coupon and
the paper tests; do not print those yet.

THE COUPON  = the centre of the new one-piece back plate: a disc 68 mm across, 2.0 mm thick, with the 1.2 mm aperture floor (four
10.5 mm holes and the 2.5 mm sighting hole), the plate wall, and the rim notch pattern (3 singles + 1 double) so it can be lined up
with the paper template. It is NOT a seat; it cannot test refit repeatability.

PRINT SETTINGS - the same as the real plate: BACK FACE DOWN, exactly as the file lies. Your usual PLA settings, 0.2 mm layers.
  - Brim: OUTER ONLY or none. Make sure the slicer does NOT put a brim inside the holes.
  - No supports (there is nothing to support).
  - Two versions, brass first if you only do one:
      (a) aperture_coupon_one_colour.stl  - all brass
      (b) aperture_coupon_BLACK_body.stl + aperture_coupon_BRASS_body.stl - import BOTH into ONE Bambu Studio object (they fit exactly,
          they are not overlapping), give the black body the black filament and the brass body the brass. Do NOT use the paint tool.

THE TEST (about 20 minutes)
  1. Print 2_REFERENCE/aperture_template_asym_v1.pdf at 100 % (no fit to page). The scale bar must measure 100 mm.
  2. Measure each of the 4 holes and the sighting hole with calipers, as far in as you can reach on the bed side AND the top side.
     Intended: 10.50 mm (acceptable 10.35 to 10.65) and 2.50 mm. Report all five numbers for each version.
  3. Lay the coupon on the template and line the rim marks of the coupon up with the 4 notch marks on the dashed r 34 circle.
     Through each hole you should see its letter (R, I, F, T) centred. Report whether any letter is clipped or off-centre, and by how much.
  4. Look at it from straight above, then tilted about 20 and 40 degrees. Are the letters still readable? Does anything from a
     neighbouring hole intrude?
  5. Brass vs black: outdoors in sun and indoors under a lamp, is there glare in the brass version? Is the black version easier to read?
  6. Hold a torch behind it. Does any light come through the floor away from the holes? (Opacity.)
  7. Black version only: try to pry or flex the black floor against the brass wall. It must not come away.
  8. Is the underside flat on a table with no rocking?

--------------------------------------------------------------------------------------------------------------------------------
COPY TO WORK  (frozen coordinates, version asym_v1; do not approximate, mirror, scale, rotate or reorder)

Version:  asym_v1   File: aperture_geometry.json   SHA-256: a37d539b04742708671a6f8608ef5e3975aca82f4068ecf44af8edda2a374aa8
Status:   PROPOSAL. Not authorised for production. The approved baseline is still the symmetric cross.

View convention: looking DOWN onto the instrument from above (the player's view, cover off). A sheet lying face-up under the
instrument is drawn in this SAME view, so NO mirror is needed. +X is to the right (3 o'clock). +Y is toward the DOUBLE notch (12 o'clock).
Origin: the centre of the plate.  Units: mm.  Sheet printed at 100 %.

Reading order: start at the double notch (12 o'clock) and sweep CLOCKWISE. The first hole met reads R, then I, then F, then T.

  Order  Letter   x (mm)     y (mm)    bearing (clockwise from 12)   radius
    1      R       +7.053     +9.708        36 deg                    12.0
    2      I      +14.095     -5.130       110 deg                    15.0
    3      F       -4.603     -9.437       206 deg                    10.5
    4      T      -12.977     +3.721       286 deg                    13.5
  Holes: round, diameter 10.5 mm (measured coupon diameters: PENDING).
  Sighting hole: centre (0, 0), diameter 2.5 mm. It sits over the sheet's centre mark. No solution letter may be placed under it.
  Floor: 1.2 mm thick, flush with the sheet (0 mm gap). The old separate mask was 0.6 mm above the sheet.
  Rim notches (radius 62.5): singles at 3, 6 and 9 o'clock; the double at 12 o'clock (two notches 6 degrees apart, centred on +Y).
  Plate locating pin: 3 o'clock, radius 54.  Four plate screws at 45/135/225/315 deg, radius 54 (M3 x 8).
  Geometry margins: furthest hole edge 20.25 mm from the centre (same as the old cross); hole-to-hole web 5.1 mm; hole-to-sighting-hole
  web 4.0 mm; every hole at least 16 degrees from any notch axis; no rotational or mirror symmetry.
  For the sheet: decoy letters must stay well away from every hole centre so only the intended letter shows through each hole
  (the old lattice kept neighbours 10.6 mm away; this pattern is NOT on that lattice, so the lattice generator cannot be reused as is).
  Printer settings for the coupon: as above; the final plate is the same orientation.
  WARNING: Work must not approximate, mirror, scale, rotate or reorder these coordinates without explicit engineering approval.
