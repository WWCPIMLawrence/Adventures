CHRONOMETER - INTEGRATED APERTURE PLATE AND BASE (production candidates, asym_v1)      NOT YET APPROVED FOR PRODUCTION

DO NOT PRINT THESE FOR THE FINAL UNITS until the aperture coupon (chronometer_aperture_coupon_v1.zip) has passed.

plate/back_plate.stl         single body (brass only: for a contrast comparison or a first fit test)
plate/back_plate_black.stl   the 1.2 mm aperture floor (black body)  \  import both into ONE Bambu Studio object,
plate/back_plate_brass.stl   the rest of the plate (brass body)      /  one filament each; they fit exactly; NOT the paint tool
plate/base.stl               the new base: no mask lip, no key slot. Your existing base (from before the lip) should also accept the new plate
                             (zero interference by CAD; not yet confirmed physically).

Print: back face down as exported. Outer brim only (no brim inside the holes). No supports. Plate about 1 h 10 min on the P1S plus about
15 min for the colour changes. Base about 1 h 20 min.

First physical test after the coupon: ONE plate on your EXISTING base. Remove and refit it 20 times; the holes must stay within 0.5 mm.
Coordinates and the 1:1 template are in the aperture coupon zip (reference folder).
